"""
tests package initialization
"""
